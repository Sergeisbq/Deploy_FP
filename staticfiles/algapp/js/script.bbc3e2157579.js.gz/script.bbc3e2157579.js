let h2 = document.getElementsByTagName('h2');
h2[0].style.textAlign = 'center';
let div = document.getElementById('container_re');
div.style.display = 'flex';
div.style.flexDirection = 'row';
div.style.justifyContent = 'space-around';
div.style.margin = '0 auto';

